package pattern_preprocessing;

import java.io.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.sparql.algebra.Algebra;
import com.hp.hpl.jena.sparql.algebra.Op;
import com.hp.hpl.jena.sparql.algebra.OpWalker;
import com.hp.hpl.jena.sparql.core.BasicPattern;
import com.hp.hpl.jena.sparql.syntax.Element;

import triple_pattern_selectivity.*;

public class PatternPreprocessing {
	//public HashMap<Integer,Long> selectivityMap = new HashMap<Integer,Long>();
	public HashMap< Integer,Triple> hm = new HashMap<Integer,Triple>();
	
	public void patternPreProcessing() throws IOException
	{
		//String dataset="/home/manisha/Downloads/pillisirpapers/pigsparql/dblp10K.n3";
		
			
			//Model model = ModelFactory.createDefaultModel();
			//model.read(new FileInputStream(dataset),null,"TTL");
			/*String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " + 
					"PREFIX dc: <http://purl.org/dc/elements/1.1/> " + 
					"PREFIX dcterms: <http://purl.org/dc/terms/> " + 
					"PREFIX bench: <http://localhost/vocabulary/bench/> " + 
					"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> " +
					"SELECT ?yr " + 
					"WHERE { " + 
					"?journal rdf:type bench:Journal. " + 
					"?journal dc:title \"Journal 1 (1940)\"^^xsd:string. " + 
					"?journal dcterms:issued ?yr " + 
					"}";*/
			String queryString ="";
			String line = null;
			File file = new File("src/sparql_queries/LUBM_Q2.sparql");
			Scanner sc = new Scanner(file);
			//BufferedReader reader = new BufferedReader(new FileReader("sparql_queries/LUBM_Q2.sparql"));
			while(sc.hasNextLine())
			{
				line=sc.nextLine();
				if(line.charAt(0)!='#')
				{
					queryString= queryString+line;
				}
			}
			sc.close();
			/*String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
						"PREFIX ub: <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#>"+
						"SELECT ?X	"+
						"WHERE"+
						"{ ?X ub:takesCourse <http://www.Department0.University0.edu/GraduateCourse0> ."+
						" ?X rdf:type ub:GraduateStudent }";*/
			BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt", true));
			writer.append("QUERY\n");
			writer.append(queryString);
			writer.append("\n");
			writer.close();
			Query query = QueryFactory.create(queryString);
			BasicPatternVisitor visitor = new BasicPatternVisitor();
			Element el = query.getQueryPattern();
			Op op = Algebra.compile(el);
			OpWalker.walk(op, visitor);
			
			List<?> patterns = visitor.getPatterns();
			
			for (Iterator<?> iter = patterns.iterator(); iter.hasNext();) {
				BasicPattern pattern = (BasicPattern) iter.next();
				int size = pattern.size();
				for(int i=0;i<size;i++)
				{
					Triple triple = pattern.get(i);
					hm.put(i, triple);
				}
			}
			/*TriplePatternSelectivity patternSel= new TriplePatternSelectivity();
			patternSel.findselectivity(hm,model);
			selectivityMap=patternSel.selectivityMap;*/
			
			
			
			
		
	}
	private void swap(ArrayList<Integer>l, int i, int j) {
		int t=l.get(i);
		l.set(i,l.get(j));
		l.set(j,t);
	}
	public void generatePermutation(ArrayList<Integer> l, ArrayList<ArrayList<Integer>> permList,int left, int right, int n) {
		int size=permList.size();
		if(size==n)
			return;
		if(left==right){
			ArrayList<Integer> temp=new ArrayList<Integer>(l);
			
			permList.add(temp);
			System.out.println(permList);
		}
		else {
			for(int i=left;i<=right;i++) {
				swap(l,left,i);
				generatePermutation(l,permList,left+1,right,n);
				swap(l,left,i);
			}
		}
		
	}
}
