package Particle;

import java.io.FileNotFoundException;
import java.util.*;

import triple_pattern_selectivity.*;

import com.hp.hpl.jena.graph.Triple; 

public class Particle {
	public ArrayList<Integer> pos=new ArrayList<Integer>();
	public ArrayList<ArrayList<Integer>> vel=new ArrayList<ArrayList<Integer>>();
	public ArrayList<Integer> pbest=new ArrayList<Integer>();
	public ArrayList<Integer> gbest = new ArrayList<Integer>();
	
	
	private ArrayList<ArrayList<Integer>>merge_ss(ArrayList<ArrayList<Integer>> ss1,ArrayList<ArrayList<Integer>> ss2) {
		ArrayList<ArrayList<Integer>> temp=new ArrayList<ArrayList<Integer>>();
		temp.addAll(ss1);
		temp.addAll(ss2);
		return temp;
	}
	private void swap(ArrayList<Integer> s, int i, int j) {
		int t=s.get(i);
		s.set(i, s.get(j));
		s.set(j,t);
	}
	private ArrayList<ArrayList<Integer>> subtract(ArrayList<Integer> s1, ArrayList<Integer> s2) {
		ArrayList<ArrayList<Integer>> vel=new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> t=new ArrayList<Integer>(s2);
		//t=s2;
		for(Integer element: s1) {
			ArrayList<Integer> temp = new ArrayList<Integer>();
			int i=s1.indexOf(element);
			int j=t.indexOf(element);
			if(i!=j) {
				temp.add(i);
				temp.add(j);
				vel.add(temp);
				swap(t,i,j);
			}
			
		}
		return vel;
	}
	private ArrayList<Integer> add(ArrayList<Integer> pos, ArrayList<ArrayList<Integer>> vel) {
		ArrayList<Integer> posNew = new ArrayList<Integer>(pos);
		//posNew=pos;
		for(ArrayList<Integer> temp : vel) {
			int i=temp.get(0);
			int j=temp.get(1);
			swap(posNew,i,j);
		}
		return posNew;
	}
	public void initialiseVel(int n) {
		Random rand = new Random();
		int k=rand.nextInt(n-1)+1;
		for(int z=1;z<=k;z++)
		{
			ArrayList<Integer> temp=new ArrayList<Integer>();
			int i=rand.nextInt(n);
			int j=rand.nextInt(n);
			while(j==i)
				j=rand.nextInt(n);
			temp.add(0);
			temp.add(1);
			vel.add(temp);
			
		}
		
	}
	public void updateVel() {
		ArrayList<ArrayList<Integer>> velNew=new ArrayList<ArrayList<Integer>>(vel);
		//velNew=vel;
		int c1=1;
		int c2=1;
		Random rand = new Random();
		//float r1=rand.nextFloat();
		//float r2=rand.nextFloat();
		float r1=1;
		float r2=1;
		float p1=c1*r1;
		float p2=c2*r2;
		if(p1>=0.5) {
			ArrayList<ArrayList<Integer>> temp1= new ArrayList<ArrayList<Integer>>(subtract(pbest,pos));
			//temp1=subtract(pbest,pos);
			velNew=merge_ss(velNew,temp1);
		}
		if(p2>=0.5)
		{
			ArrayList<ArrayList<Integer>> temp1= new ArrayList<ArrayList<Integer>>(subtract(gbest,pos));
			//temp1=subtract(gbest,pos);
			velNew=merge_ss(velNew,temp1);
		}
		vel=velNew;
		
	}
	public void updatePos() {
		pos=add(pos,vel);
	}
	private double calcSelectivity(Triple t, CalSelectivity cs) {
		String subj =t.getSubject().toString();
		String pred = t.getPredicate().toString();
		String obj = t.getObject().toString();
		if(subj.charAt(0)!='?' && subj.charAt(0)!='_' && subj.charAt(0)!='"' && subj.charAt(0)!='\'')
		{
			subj="<"+subj+">";
		}
		if(pred.charAt(0)!='?' && pred.charAt(0)!='_' && pred.charAt(0)!='"' && pred.charAt(0)!='\'')
			pred="<"+pred+">";
		if(obj.charAt(0)!='?' && obj.charAt(0)!='_' && obj.charAt(0)!='"' && obj.charAt(0)!='\'')
			obj="<"+obj+">";
		double tripleSel= cs.getSubjectSelectivity(subj)*cs.getPredSelectivity(pred)*cs.getObjSelectivity(pred, obj);
		return tripleSel;
	}
	public double calcFitnessFunc(HashMap< Integer,Triple> hm, ArrayList<Integer> position, CalSelectivity cs) throws FileNotFoundException{
		//using Rosenbrock’s function
		//CalSelectivity cs = new CalSelectivity();
		//cs.initialize();
		/*System.out.println("In fitness function...........");
		System.out.println(hm);
		System.out.println(position);*/
		double sum=0;
		int n=position.size();
		for(int i=0;i<n-1;i++) {
			//System.out.println(i);
			Triple triple1=hm.get(position.get(i));
			double tripleSel1= calcSelectivity(triple1,cs);
			
			Triple triple2=hm.get(i+1);
			double tripleSel2= calcSelectivity(triple2,cs);
			
			sum= sum+ 100*((tripleSel2-tripleSel1)*(tripleSel2-tripleSel1))+ (tripleSel1-1)*(tripleSel1-1);
			//System.out.println("sum"+sum);
			
			
		}
		double fitnessValue= sum;
		//System.out.println("calculating fitness value"+fitnessValue);
		return fitnessValue;
	}
	public void pBestUpdate(HashMap< Integer,Triple> hm, CalSelectivity cs) throws FileNotFoundException {
		double prev = calcFitnessFunc(hm,pbest,cs);
		double new_ = calcFitnessFunc(hm,pos,cs);
		if(new_<prev)	//minimising fitness function
			pbest=pos;
		
	}
	public static void main(String args[]) {
		Particle p=new Particle();
		ArrayList<Integer> t1=new ArrayList<Integer>();
		ArrayList<Integer> t2=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> temp=new ArrayList<ArrayList<Integer>>();
		
		/*t1.add(1);
		t1.add(2);
		t2.add(0);
		t2.add(2);
		temp.add(t2);
		p.vel.add(t1);
		System.out.println(p.vel);
		//t1.add(3);
		p.pos=t1;
		p.pos.add(3);
		System.out.println(p.pos);
		p.updatePos();
		System.out.println(p.pos);
		System.out.println(p.merge_ss(p.vel, temp));*/
		
		t1.add(1);
		t1.add(3);
		t1.add(4);
		t1.add(5);
		t1.add(2);
		System.out.println(t1);
		t2.add(3);
		t2.add(1);
		t2.add(2);
		t2.add(5);
		t2.add(4);
		System.out.println(t2);
		System.out.println(p.subtract(t1, t2));
		
		//ArrayList<Integer> t2=new ArrayList
	}
	
}
