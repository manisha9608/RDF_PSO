package triple_pattern_crossjoin;


import java.util.HashMap;
import java.util.Map;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.rdf.model.Model;


import triple_pattern_selectivity.*;

public class TriplePatternCrossJoin {
	public static HashMap<Integer, HashMap<Integer,Long>> crossjoinmap = new HashMap<Integer,HashMap<Integer,Long>>();
	public static void findCrossJoin(HashMap<Integer,Triple> hm, Model model)
	{
		int size = hm.size();
		TriplePatternSelectivity singleTripleSel=new TriplePatternSelectivity();
		for(int i=0;i<size;i++)
		{
			Long sel1 = singleTripleSel.selectivityMap.get(i);
			
			HashMap<Integer,Long> inner = new HashMap<Integer,Long>();
			
			for (Map.Entry<Integer,Long> e : singleTripleSel.selectivityMap.entrySet()) {
				Integer index2 = e.getKey();
				Long sel2 = e.getValue();
				
				inner.put(index2,sel1*sel2);
				
			}
			crossjoinmap.put(i,inner);
		}
	}
	
}
