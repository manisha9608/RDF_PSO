package triple_pattern_selectivity;


import java.util.HashMap;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.sparql.core.BasicPattern;
import com.hp.hpl.jena.rdf.model.Model;


public class TriplePatternSelectivity {
	//private static HashMap<Integer, HashMap<Integer,Long>> crossjoinmap = new HashMap<Integer,HashMap<Integer,Long>>();
	public HashMap<Integer,Long> selectivityMap = new HashMap<Integer,Long>();
	public void findselectivity(HashMap<Integer,Triple> hm, Model model)
	 {
			Selectivity sel = new Selectivity(model);
			
			int size = hm.size();
			System.out.println();
			
			////// FINDING SINGLE TRIPLE SELECTIVITY WIHTOUT DEPENDING ON OTHERS //////
			for(int i=0;i<size;i++)
			{
				BasicPattern bp = new BasicPattern();
				bp.add(sel.normalize(hm.get(i)));
				long selectivity = sel.calculate(bp);
				selectivityMap.put(i,selectivity);
				//System.out.println(i+" : "+selectivity);
			}
	 }
}
