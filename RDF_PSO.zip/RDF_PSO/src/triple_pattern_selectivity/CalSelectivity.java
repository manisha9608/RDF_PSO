package triple_pattern_selectivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class CalSelectivity {

	private HashMap<String, Double> predmap = new HashMap<>();
	private HashMap<String, HashMap<String,Double>> objmap = new HashMap<>();
	private HashMap<String, Double> unboundobjmap = new HashMap<>();
	private static int Resources = 0;
	
	private static int totaltriples = 0;
	
	private void findPredSel() throws FileNotFoundException
	{
		File file =	new File("predsel");
	    Scanner sc = new Scanner(file);
	    
	    while (sc.hasNextLine())
	    {
	    	String line = sc.nextLine();
	    	String pred_count[] = line.split("\t");
	    	String pred = pred_count[0];
	    	int predcount = Integer.parseInt(pred_count[1]);
	    	totaltriples = Integer.parseInt(pred_count[2]);
	    	
	    	double predsel = predcount/(double)totaltriples;
	    	predmap.put(pred,predsel);
	    }	    
	    sc.close();
	}
	
	private void findObjSel() throws FileNotFoundException
	{
		File file =	new File("objsel");
	    Scanner sc = new Scanner(file);
	    while (sc.hasNextLine())
	    {
	    	String line = sc.nextLine();
	    	String pred_obj_count[] = line.split("\t");
	    	
	    	String pred = pred_obj_count[0];
	    	String obj = pred_obj_count[1];
	    	double objcount = Double.parseDouble(pred_obj_count[2]);
	    	double predsel = predmap.get(pred);
	    	double predcount = predsel * totaltriples;
	    	
	    	double objsel = objcount/predcount;	    	
	    	
	    	if(!objmap.containsKey(obj))
	    	{
	    		HashMap<String,Double> innerMap = new HashMap<>();
	    		innerMap.put(pred, objsel);
	    		objmap.put(obj, innerMap);
	    	}
	    	else
	    	{
	    		HashMap<String,Double> innerMap = objmap.get(obj);
	    		innerMap.put(pred,objsel);
	    		objmap.put(obj, innerMap);
	    	}
	    	
	    }	    
	    sc.close();
	    /*
	    HashMap<String,Double> x = objmap.get("<http://www.Department13.University0.edu/AssociateProfessor11>");
	    
	    for (HashMap.Entry<String, Double> entry : x.entrySet()) {
	        System.out.println(entry.getKey()+" : "+entry.getValue());
	    }*/
	}
	
	private void findUnboundObjsel()
	{
		for (HashMap.Entry<String, HashMap<String,Double>> entry : objmap.entrySet()) {
			String obj = entry.getKey();
			
			HashMap<String,Double> pred_objsel = entry.getValue();
			double unbound_objsel = 0.0;
			for (HashMap.Entry<String, Double> x : pred_objsel.entrySet()) {
				
				double objsel = x.getValue();
				unbound_objsel += objsel;
			}
			unboundobjmap.put(obj, unbound_objsel);
		}
		
		//System.out.println(unboundobjmap.get("<http://www.Department13.University0.edu/AssociateProfessor11>"));
	}
	
	private void findResources() throws FileNotFoundException
	{
		File file =	new File("subjectcount");
	    Scanner sc = new Scanner(file);
	    int uniquesubjects = 0;
	    while (sc.hasNextLine())
	    {
	    	uniquesubjects++;
	    	String line = sc.nextLine();
	    }
	    Resources = uniquesubjects;
	}
	
	public void initialize() throws FileNotFoundException
	{
		findPredSel();
		findObjSel();
		findUnboundObjsel();
		findResources();
	}
	
	public double getSubjectSelectivity(String sub)
	{
		if(sub.charAt(0)=='?')
			return 1.0;
		
		return 1.0/Resources;
	}
	
	public double getPredSelectivity(String pred)
	{
		if(pred.charAt(0)=='?')
			return 1.0;
		
		return predmap.get(pred);
	}
	
	public double getObjSelectivity(String pred,String obj)
	{
		if(obj.charAt(0)=='?')
			return 1.0;
		
		if(pred.charAt(0)=='?')
			return unboundobjmap.get(obj);
		
		HashMap<String,Double> pred_objsel = objmap.get(obj);
		double sel = pred_objsel.get(pred);
		return sel;
	}
	
	public static void main(String args[]) throws FileNotFoundException
	{
		CalSelectivity cs = new CalSelectivity();
		cs.initialize();
		double x = cs.getSubjectSelectivity("<http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#advisor>");
		System.out.println(x);
		
	}
}
