package PSOImpl;

import java.io.*;
import java.util.*;

import com.hp.hpl.jena.graph.Triple;

import pattern_preprocessing.PatternPreprocessing;
import triple_pattern_selectivity.CalSelectivity;
import Particle.*;

public class PSOImpl {
	private HashMap< Integer,Triple> hm = new HashMap<Integer,Triple>();
	private ArrayList<Particle> particles =new ArrayList<Particle>();
	private int n;
	
	public void updateGbest(CalSelectivity cs) throws FileNotFoundException {
		double min=10000;
		ArrayList<Integer> pos_min=new ArrayList<Integer>();
		for(Particle p: particles) {
			double temp=p.calcFitnessFunc(hm, p.pbest, cs);
			/*System.out.println("for particle p");
			System.out.println(p.pos);
			System.out.println("calculating fitness value for pbest");
			System.out.println(temp);*/
			if(temp<min) {
				min=temp;
				pos_min=p.pbest;
			}
			for(Particle particle: particles) {
				particle.gbest=pos_min;
			}
			
			
		}
	}
	
	private void PSO () throws FileNotFoundException, IOException {
		int epochs =150;
		CalSelectivity cs =new CalSelectivity();
		cs.initialize();
		PatternPreprocessing process = new PatternPreprocessing();
		process.patternPreProcessing();
		hm=process.hm;
		ArrayList<Integer> particleKey =new ArrayList<Integer>(hm.keySet());
		ArrayList<ArrayList<Integer>> particlesPos = new ArrayList<ArrayList<Integer>>();
		n=particleKey.size();
		int left=0;
		int right=n-1;
		System.out.println(n+""+left+""+right);
		//Generate permutation for Position
		process.generatePermutation(particleKey, particlesPos, left, right, n);
		//Initialise particle
		for(ArrayList<Integer> particlePos : particlesPos) {
			Particle p=new Particle();
			p.pos=particlePos;
			p.pbest=p.pos;
			p.initialiseVel(n);
			particles.add(p);
		}
		//initialise gbest
		updateGbest(cs);
		for(Particle p: particles)
		{
			System.out.println("initialisation");
			System.out.println(p.pos);
			System.out.println(p.vel);
			System.out.println(p.pbest+","+p.gbest);
			System.out.println("iteration end");
		}
		
		for (int i=0;i<epochs;i++) {
			for(Particle particle: particles) {
				particle.updateVel();
				particle.updatePos();
				
				particle.pBestUpdate(hm, cs);
				updateGbest(cs);
				//print values
					System.out.println("iteration"+i);
					System.out.println(particle.pos);
					System.out.println(particle.vel);
					System.out.println(particle.pbest+","+particle.gbest);
					System.out.println("iteration end");
				
			}
			
			
		}
	}
	public static void main(String args[]) throws FileNotFoundException, IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt", true));
		writer.append("Triple Sequence\n");
		PSOImpl implementation =new PSOImpl();
		implementation.PSO();
		
		ArrayList<Integer> pos=implementation.particles.get(0).gbest;
		System.out.println(pos);
		for (int i: pos) {
			System.out.println(implementation.hm.get(i));
			writer.append(implementation.hm.get(i).toString());
			writer.append("\n");
			
		}
		writer.close();
		
	}
	
	
}
